var string = "Count words in a string Count words in a string";
var count = string.split(" ").length;

console.log("Number of words: " + count);