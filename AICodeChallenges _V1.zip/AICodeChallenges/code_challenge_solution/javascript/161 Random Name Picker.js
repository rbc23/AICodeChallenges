let names = ["John", "Emma", "Michael", "Sophia", "David", "Olivia", "Joseph", "Emily", "Daniel", "Ava"];

let randomIndex = Math.floor(Math.random() * names.length);
let randomName = names[randomIndex];

console.log(randomName);