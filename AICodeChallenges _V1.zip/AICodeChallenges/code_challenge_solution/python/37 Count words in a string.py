input_string = input("Enter a string: ")
word_count = len(input_string.split())
print("Number of words in the string:", word_count)