import random

names = ["John", "Jane", "Emily", "David", "Sarah", "Michael"]

random_name = random.choice(names)

print("Randomly picked name:", random_name)